require(require('path').join(__dirname, 'server/server.js'));
