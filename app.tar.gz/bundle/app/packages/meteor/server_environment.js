Meteor = {
  is_client: false,
  is_server: true
};
