Meteor.default_server.autopublish();
