// for a little while, accept Sky as an alias for Meteor.
// remove this once people have transitioned.
if (typeof Sky === "undefined") Sky = Meteor;
